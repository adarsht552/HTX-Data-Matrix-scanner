import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'homepage.dart';
import 'appconstant.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _cameraInitialized = false;
  
  @override
  void initState() {
    super.initState();
    _initCamera();
  }
  
  Future<void> _initCamera() async {
    try {
      // Initialize camera
      final cameras = await availableCameras();
      
      // Mark as initialized
      setState(() {
        _cameraInitialized = true;
      });
      
      // Allow splash screen to show for at least 2 seconds
      Timer(Duration(seconds: 2), () {
        if (mounted && _cameraInitialized) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => ScannerScreen(),
            ),
          );
        }
      });
    } catch (e) {
      print('Error initializing camera: $e');
      // Even if camera init fails, navigate to main screen after delay
      Timer(Duration(seconds: 3), () {
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => ScannerScreen(),
            ),
          );
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.appbarColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Container(
              width: 150,
              height: 150,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child:  Center(
                child:    Image.asset('assets/images/HanuTechX.png'),
              ),
            ),
            SizedBox(height: 30),
            // App Name
            const Text(
              'Datamatrix Scanner',
              style: TextStyle(
                fontSize: AppConstants.titleFontSize,
                fontWeight: AppConstants.titleFontWeight,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 20),
            // Loading indicator
       
            SizedBox(height: 20),
            // Status text
            Text(
              _cameraInitialized 
                  ? 'Camera initialized, loading app...' 
                  : 'Initializing camera...',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }
} 