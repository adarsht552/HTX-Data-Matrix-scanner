package com.example.htxdatamatrix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
